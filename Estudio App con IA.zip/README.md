
  # Estudio App con IA

  This is a code bundle for Estudio App con IA. The original project is available at https://www.figma.com/design/S4EGbzcfEjCjdcqp8F9pAW/Estudio-App-con-IA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  