import { useState } from 'react';
import { User, Calendar, Wrench, BookOpen } from 'lucide-react';
import UserProfile from './components/UserProfile';
import Planner from './components/Planner';
import Tools from './components/Tools';
import Wiki from './components/Wiki';

export default function App() {
  const [activeTab, setActiveTab] = useState('planner');

  return (
    <div className="size-full flex flex-col bg-[#FEFDFB] max-w-md mx-auto">
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'user' && <UserProfile />}
        {activeTab === 'planner' && <Planner />}
        {activeTab === 'tools' && <Tools />}
        {activeTab === 'wiki' && <Wiki />}
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-[#FEFDF9] border-t border-[#6BBDE2]/20 shadow-lg">
        <div className="flex justify-around items-center h-20 px-4">
          <button
            onClick={() => setActiveTab('wiki')}
            className={`flex flex-col items-center justify-center gap-1 flex-1 transition-all ${
              activeTab === 'wiki' ? 'text-[#6BBDE2]' : 'text-gray-400'
            }`}
          >
            <BookOpen className={`w-7 h-7 ${activeTab === 'wiki' ? 'scale-110' : ''} transition-transform`} />
            <span className="text-xs">Wiki</span>
          </button>
          
          <button
            onClick={() => setActiveTab('tools')}
            className={`flex flex-col items-center justify-center gap-1 flex-1 transition-all ${
              activeTab === 'tools' ? 'text-[#6BBDE2]' : 'text-gray-400'
            }`}
          >
            <Wrench className={`w-7 h-7 ${activeTab === 'tools' ? 'scale-110' : ''} transition-transform`} />
            <span className="text-xs">Tools</span>
          </button>
          
          <button
            onClick={() => setActiveTab('planner')}
            className={`flex flex-col items-center justify-center gap-1 flex-1 transition-all ${
              activeTab === 'planner' ? 'text-[#6BBDE2]' : 'text-gray-400'
            }`}
          >
            <Calendar className={`w-7 h-7 ${activeTab === 'planner' ? 'scale-110' : ''} transition-transform`} />
            <span className="text-xs">Planner</span>
          </button>
          
          <button
            onClick={() => setActiveTab('user')}
            className={`flex flex-col items-center justify-center gap-1 flex-1 transition-all ${
              activeTab === 'user' ? 'text-[#6BBDE2]' : 'text-gray-400'
            }`}
          >
            <User className={`w-7 h-7 ${activeTab === 'user' ? 'scale-110' : ''} transition-transform`} />
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}