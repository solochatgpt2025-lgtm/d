import { useState } from 'react';
import { ArrowLeft, Plus, FileText, Image, Mic2, Save, Trash2 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';

interface NotebookViewerProps {
  notebook: {
    id: number;
    title: string;
    notes: number;
    color: string;
  };
  onBack: () => void;
}

export default function NotebookViewer({ notebook, onBack }: NotebookViewerProps) {
  const [pages, setPages] = useState([
    { id: 1, type: 'note', title: 'Introduction to Calculus', content: 'Derivatives represent the rate of change...', date: 'Sep 28' },
    { id: 2, type: 'photo', title: 'Whiteboard Notes', imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400&h=300', date: 'Sep 27' },
    { id: 3, type: 'ai-summary', title: 'Lecture Summary - Integrals', content: 'Key concepts: definite integrals, area under curves...', date: 'Sep 26' },
  ]);
  const [currentPage, setCurrentPage] = useState(0);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [newPageType, setNewPageType] = useState<'note' | 'photo' | 'ai-summary'>('note');
  const [newContent, setNewContent] = useState('');

  const handleAddPage = () => {
    const newPage = {
      id: pages.length + 1,
      type: newPageType,
      title: newPageType === 'note' ? 'New Note' : newPageType === 'photo' ? 'New Photo' : 'AI Summary',
      content: newContent,
      date: 'Today',
    };
    setPages([...pages, newPage]);
    setNewContent('');
    setAddDialogOpen(false);
  };

  const currentPageData = pages[currentPage];

  return (
    <div className="h-full flex flex-col bg-[#FEFDFB]">
      {/* Header */}
      <div className={`p-6 pb-8 ${notebook.color} rounded-b-3xl shadow-lg relative`}>
        <button onClick={onBack} className="absolute top-6 left-6">
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <div className="text-center mt-8">
          <h2 className="text-white">{notebook.title}</h2>
          <p className="text-white/90 mt-1">{pages.length} pages</p>
        </div>
      </div>

      {/* Page Navigation */}
      <div className="px-6 mt-[-20px] mb-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {pages.map((page, index) => (
            <button
              key={page.id}
              onClick={() => setCurrentPage(index)}
              className={`flex-shrink-0 px-4 py-2 rounded-xl transition-all ${
                currentPage === index
                  ? 'bg-[#6BBDE2] text-white shadow-md'
                  : 'bg-[#FEFDF9] text-gray-600 border border-[#6BBDE2]/20'
              }`}
            >
              {index + 1}
            </button>
          ))}
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <button className="flex-shrink-0 w-10 h-10 rounded-xl bg-[#6BBDE2] text-white flex items-center justify-center shadow-md">
                <Plus className="w-5 h-5" />
              </button>
            </DialogTrigger>
            <DialogContent className="max-w-[90%] bg-[#FEFDF9] rounded-3xl border-[#6BBDE2]/20">
              <DialogHeader>
                <DialogTitle className="text-[#2c3e50]">Add New Page</DialogTitle>
                <DialogDescription className="text-gray-600">Choose a page type and add your content</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  <Button
                    onClick={() => setNewPageType('note')}
                    variant={newPageType === 'note' ? 'default' : 'outline'}
                    className={`flex flex-col items-center gap-2 h-auto py-4 rounded-2xl ${
                      newPageType === 'note'
                        ? 'bg-[#6BBDE2] hover:bg-[#5aaedb] text-white'
                        : 'border-[#6BBDE2]/30 text-[#6BBDE2] hover:bg-[#e8f4f8]'
                    }`}
                  >
                    <FileText className="w-6 h-6" />
                    <span className="text-xs">Note</span>
                  </Button>
                  <Button
                    onClick={() => setNewPageType('photo')}
                    variant={newPageType === 'photo' ? 'default' : 'outline'}
                    className={`flex flex-col items-center gap-2 h-auto py-4 rounded-2xl ${
                      newPageType === 'photo'
                        ? 'bg-[#6BBDE2] hover:bg-[#5aaedb] text-white'
                        : 'border-[#6BBDE2]/30 text-[#6BBDE2] hover:bg-[#e8f4f8]'
                    }`}
                  >
                    <Image className="w-6 h-6" />
                    <span className="text-xs">Photo</span>
                  </Button>
                  <Button
                    onClick={() => setNewPageType('ai-summary')}
                    variant={newPageType === 'ai-summary' ? 'default' : 'outline'}
                    className={`flex flex-col items-center gap-2 h-auto py-4 rounded-2xl ${
                      newPageType === 'ai-summary'
                        ? 'bg-[#6BBDE2] hover:bg-[#5aaedb] text-white'
                        : 'border-[#6BBDE2]/30 text-[#6BBDE2] hover:bg-[#e8f4f8]'
                    }`}
                  >
                    <Mic2 className="w-6 h-6" />
                    <span className="text-xs">AI Summary</span>
                  </Button>
                </div>
                {newPageType === 'note' && (
                  <Textarea
                    placeholder="Write your note here..."
                    className="min-h-[150px] rounded-2xl border-[#6BBDE2]/30"
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                  />
                )}
                {newPageType === 'photo' && (
                  <div className="p-8 border-2 border-dashed border-[#6BBDE2]/30 rounded-2xl text-center">
                    <Image className="w-12 h-12 text-[#6BBDE2] mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Click to upload photo</p>
                  </div>
                )}
                {newPageType === 'ai-summary' && (
                  <div className="p-6 bg-[#e8f4f8] rounded-2xl">
                    <p className="text-sm text-gray-700">
                      Select an AI recording from your library to import as a summary page.
                    </p>
                  </div>
                )}
                <Button onClick={handleAddPage} className="w-full bg-[#6BBDE2] hover:bg-[#5aaedb] text-white shadow-md rounded-2xl">
                  Add Page
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Page Content */}
      <div className="flex-1 overflow-y-auto px-6 pb-6">
        <Card className="bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-lg rounded-3xl overflow-hidden">
          {/* Page Header */}
          <div className="p-6 border-b border-[#6BBDE2]/20 bg-gradient-to-r from-[#e8f4f8] to-[#FEFDF9]">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-[#2c3e50]">{currentPageData.title}</h3>
                <div className="flex items-center gap-2 mt-2">
                  <Badge
                    variant="outline"
                    className={`text-xs ${
                      currentPageData.type === 'note'
                        ? 'bg-[#e8f4f8] text-[#6BBDE2] border-[#6BBDE2]'
                        : currentPageData.type === 'photo'
                        ? 'bg-[#fff9e6] text-[#FFC107] border-[#FFC107]'
                        : 'bg-purple-50 text-purple-600 border-purple-600'
                    }`}
                  >
                    {currentPageData.type === 'note' ? 'Note' : currentPageData.type === 'photo' ? 'Photo' : 'AI Summary'}
                  </Badge>
                  <span className="text-xs text-gray-500">{currentPageData.date}</span>
                </div>
              </div>
              <button className="text-gray-400 hover:text-red-500 transition-colors">
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Page Body */}
          <div className="p-6">
            {currentPageData.type === 'note' && (
              <div className="prose prose-sm max-w-none">
                <p className="text-gray-700 leading-relaxed">{currentPageData.content}</p>
              </div>
            )}
            {currentPageData.type === 'photo' && (
              <div className="flex items-center justify-center">
                <img
                  src={currentPageData.imageUrl}
                  alt={currentPageData.title}
                  className="max-w-full h-auto rounded-2xl shadow-md"
                />
              </div>
            )}
            {currentPageData.type === 'ai-summary' && (
              <div className="space-y-4">
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Mic2 className="w-4 h-4 text-purple-600" />
                    <span className="text-sm text-purple-900">AI Generated Summary</span>
                  </div>
                  <p className="text-sm text-gray-700 leading-relaxed">{currentPageData.content}</p>
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex gap-3 mt-4">
          <Button
            onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
            disabled={currentPage === 0}
            variant="outline"
            className="flex-1 rounded-2xl border-[#6BBDE2]/30 text-[#6BBDE2] hover:bg-[#e8f4f8]"
          >
            Previous
          </Button>
          <Button
            onClick={() => setCurrentPage(Math.min(pages.length - 1, currentPage + 1))}
            disabled={currentPage === pages.length - 1}
            className="flex-1 bg-[#6BBDE2] hover:bg-[#5aaedb] text-white shadow-md rounded-2xl"
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}