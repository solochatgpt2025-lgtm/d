import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Plus, CheckCircle2, Circle, CalendarDays, Clock, Star, Trash2, PlayCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';

type TaskStatus = 'not-started' | 'in-progress' | 'completed';

interface Task {
  id: number;
  title: string;
  status: TaskStatus;
  time: string;
}

export default function Planner() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: 'Study Chapter 5', status: 'in-progress', time: '10:00 AM' },
    { id: 2, title: 'Math exercises', status: 'completed', time: '2:00 PM' },
    { id: 3, title: 'Review history notes', status: 'not-started', time: '4:00 PM' },
  ]);

  const updateTaskStatus = (id: number, status: TaskStatus) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, status } : task
    ));
  };

  const deleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-7 h-7 text-[#6BBDE2]" />;
      case 'in-progress':
        return <PlayCircle className="w-7 h-7 text-[#FFC107]" />;
      case 'not-started':
        return <Circle className="w-7 h-7 text-gray-300" />;
    }
  };

  const getStatusBadge = (status: TaskStatus) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-[#6BBDE2] text-white border-0 text-xs">Completed</Badge>;
      case 'in-progress':
        return <Badge className="bg-[#FFC107] text-white border-0 text-xs">In Progress</Badge>;
      case 'not-started':
        return <Badge variant="outline" className="border-gray-300 text-gray-500 text-xs">Not Started</Badge>;
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#FEFDFB]">
      <div className="p-6 pb-8 bg-gradient-to-br from-[#6BBDE2] to-[#4db6e0] text-white rounded-b-3xl shadow-lg">
        <h1 className="text-white">My Planner</h1>
        <p className="text-white/90 mt-1">Organize your study week</p>
      </div>

      <Tabs defaultValue="tasks" className="flex-1 flex flex-col">
        <TabsList className="mx-6 mt-[-20px] grid w-auto grid-cols-3 bg-[#FEFDF9] shadow-md border border-[#6BBDE2]/20 rounded-2xl">
          <TabsTrigger value="schedule" className="rounded-xl data-[state=active]:bg-[#6BBDE2] data-[state=active]:text-white">Schedule</TabsTrigger>
          <TabsTrigger value="calendar" className="rounded-xl data-[state=active]:bg-[#6BBDE2] data-[state=active]:text-white">Calendar</TabsTrigger>
          <TabsTrigger value="tasks" className="rounded-xl data-[state=active]:bg-[#6BBDE2] data-[state=active]:text-white">Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule" className="flex-1 p-6 space-y-3 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#2c3e50]">Weekly Schedule</h3>
            <Button size="sm" className="bg-[#6BBDE2] hover:bg-[#5aaedb] text-white rounded-full shadow-md">
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>
          
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day, index) => (
            <Card key={day} className="p-5 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
              <h4 className="mb-3 text-[#2c3e50]">{day}</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-[#e8f4f8] to-[#d0ebf5] rounded-xl">
                  <Clock className="w-4 h-4 text-[#6BBDE2]" />
                  <div className="flex-1">
                    <p className="text-sm text-[#2c3e50]">Mathematics</p>
                    <p className="text-xs text-gray-500">9:00 - 10:30 AM</p>
                  </div>
                  <Badge variant="outline" className="text-xs border-[#6BBDE2] text-[#6BBDE2]">2h</Badge>
                </div>
                {index % 2 === 0 && (
                  <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-[#fff9e6] to-[#ffecb3] rounded-xl">
                    <Clock className="w-4 h-4 text-[#FFC107]" />
                    <div className="flex-1">
                      <p className="text-sm text-[#2c3e50]">History</p>
                      <p className="text-xs text-gray-500">2:00 - 3:30 PM</p>
                    </div>
                    <Badge variant="outline" className="text-xs border-[#FFC107] text-[#FFC107]">1.5h</Badge>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="calendar" className="flex-1 p-6 space-y-4 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#2c3e50]">Important Dates</h3>
            <Button size="sm" className="bg-[#6BBDE2] hover:bg-[#5aaedb] text-white rounded-full shadow-md">
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </div>

          <Card className="p-5 bg-gradient-to-r from-red-50 to-red-100 border-l-4 border-l-red-500 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-red-500 rounded-2xl flex items-center justify-center shadow-md">
                <CalendarDays className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-[#2c3e50]">Final Exam - Mathematics</h4>
                <p className="text-sm text-gray-600 mt-1">October 5, 2025</p>
                <Badge className="mt-2 bg-red-500 text-white border-0">In 5 days</Badge>
              </div>
            </div>
          </Card>

          <Card className="p-5 bg-gradient-to-r from-orange-50 to-orange-100 border-l-4 border-l-orange-500 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-md">
                <CalendarDays className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-[#2c3e50]">Project Due - History</h4>
                <p className="text-sm text-gray-600 mt-1">October 12, 2025</p>
                <Badge variant="outline" className="mt-2 border-orange-500 text-orange-600">In 12 days</Badge>
              </div>
            </div>
          </Card>

          <Card className="p-5 bg-gradient-to-r from-[#e8f4f8] to-[#d0ebf5] border-l-4 border-l-[#6BBDE2] shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-[#6BBDE2] rounded-2xl flex items-center justify-center shadow-md">
                <CalendarDays className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-[#2c3e50]">Oral Presentation - Literature</h4>
                <p className="text-sm text-gray-600 mt-1">October 20, 2025</p>
                <Badge variant="outline" className="mt-2 border-[#6BBDE2] text-[#6BBDE2]">In 20 days</Badge>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="flex-1 p-6 space-y-3 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#2c3e50]">Today's Tasks</h3>
            <Button size="sm" className="bg-[#6BBDE2] hover:bg-[#5aaedb] text-white rounded-full shadow-md">
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </div>

          {tasks.map(task => (
            <Card key={task.id} className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="mt-1">
                      {getStatusIcon(task.status)}
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-[#FEFDF9] border-[#6BBDE2]/20 rounded-2xl">
                    <DropdownMenuItem 
                      onClick={() => updateTaskStatus(task.id, 'not-started')}
                      className="cursor-pointer rounded-xl focus:bg-[#e8f4f8]"
                    >
                      <Circle className="w-4 h-4 mr-2 text-gray-400" />
                      Not Started
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => updateTaskStatus(task.id, 'in-progress')}
                      className="cursor-pointer rounded-xl focus:bg-[#fff9e6]"
                    >
                      <PlayCircle className="w-4 h-4 mr-2 text-[#FFC107]" />
                      In Progress
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => updateTaskStatus(task.id, 'completed')}
                      className="cursor-pointer rounded-xl focus:bg-[#e8f4f8]"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2 text-[#6BBDE2]" />
                      Completed
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <div className="flex-1">
                  <p className={task.status === 'completed' ? 'line-through text-gray-400' : 'text-[#2c3e50]'}>
                    {task.title}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-xs text-gray-500">{task.time}</p>
                    {getStatusBadge(task.status)}
                  </div>
                </div>
                <button 
                  onClick={() => deleteTask(task.id)}
                  className="mt-1 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </Card>
          ))}

          <Card className="p-6 bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30 shadow-md">
            <div className="text-center">
              <div className="w-14 h-14 bg-[#6BBDE2] rounded-full mx-auto mb-3 flex items-center justify-center shadow-lg">
                <Star className="w-7 h-7 text-white" />
              </div>
              <p className="text-[#2c3e50]">1 of 3 tasks completed</p>
              <p className="text-sm text-gray-600 mt-1">Keep going!</p>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}