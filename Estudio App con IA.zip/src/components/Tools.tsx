import { useState } from 'react';
import { Bell, Mic, Lightbulb, CreditCard, FileCheck, Trophy, Timer } from 'lucide-react';
import { Card } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import PomodoroTimer from './tools/PomodoroTimer';
import FlashCards from './tools/FlashCards';
import AIRecord from './tools/AIRecord';
import PopNotifications from './tools/PopNotifications';
import FeynmanTechnique from './tools/FeynmanTechnique';
import TestSystem from './tools/TestSystem';

export default function Tools() {
  const [openDialog, setOpenDialog] = useState<string | null>(null);

  const tools = [
    {
      id: 'notifications',
      title: 'Pop Notifications',
      description: 'Get random quiz questions',
      icon: Bell,
      color: 'from-[#6BBDE2] to-[#4db6e0]',
      bgColor: 'bg-[#e8f4f8]',
      textColor: 'text-[#6BBDE2]',
    },
    {
      id: 'record',
      title: 'AI Record',
      description: 'Transcribe and summarize audio',
      icon: Mic,
      color: 'from-[#8dd4f0] to-[#6BBDE2]',
      bgColor: 'bg-[#e8f4f8]',
      textColor: 'text-[#4db6e0]',
    },
    {
      id: 'feynman',
      title: 'Feynman Technique',
      description: 'Simplify complex concepts',
      icon: Lightbulb,
      color: 'from-[#FFC107] to-[#ffb300]',
      bgColor: 'bg-[#fff9e6]',
      textColor: 'text-[#FFC107]',
    },
    {
      id: 'flashcards',
      title: 'Flash Cards',
      description: 'AI-powered study cards',
      icon: CreditCard,
      color: 'from-[#8dd4f0] to-[#6BBDE2]',
      bgColor: 'bg-[#e8f4f8]',
      textColor: 'text-[#6BBDE2]',
    },
    {
      id: 'test',
      title: 'Test',
      description: 'Practice with quizzes',
      icon: FileCheck,
      color: 'from-[#6BBDE2] to-[#4db6e0]',
      bgColor: 'bg-[#e8f4f8]',
      textColor: 'text-[#4db6e0]',
    },
    {
      id: 'final-test',
      title: 'Final Test',
      description: 'Challenge every 3 hours - Win rewards',
      icon: Trophy,
      color: 'from-[#FFC107] to-[#ffb300]',
      bgColor: 'bg-[#fff9e6]',
      textColor: 'text-[#FFC107]',
    },
    {
      id: 'pomodoro',
      title: 'Pomodoro',
      description: 'Manage your study time',
      icon: Timer,
      color: 'from-[#ffd54f] to-[#FFC107]',
      bgColor: 'bg-[#fff9e6]',
      textColor: 'text-[#FFC107]',
    },
  ];

  return (
    <div className="h-full flex flex-col bg-[#FEFDFB]">
      <div className="p-6 pb-8 bg-gradient-to-br from-[#6BBDE2] to-[#4db6e0] text-white rounded-b-3xl shadow-lg">
        <h1 className="text-white">AI Tools</h1>
        <p className="text-white/90 mt-1">Boost your learning</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 pb-6">
        {tools.map((tool) => {
          const Icon = tool.icon;
          return (
            <Dialog key={tool.id} open={openDialog === tool.id} onOpenChange={(open) => setOpenDialog(open ? tool.id : null)}>
              <DialogTrigger asChild>
                <Card className="p-5 bg-[#FEFDF9] border-[#6BBDE2]/20 cursor-pointer hover:shadow-lg transition-all hover:scale-[1.02] shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className={`w-16 h-16 ${tool.bgColor} rounded-2xl flex items-center justify-center shadow-md`}>
                      <Icon className={`w-8 h-8 ${tool.textColor}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-[#2c3e50]">{tool.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{tool.description}</p>
                    </div>
                    <span className="text-[#6BBDE2] text-xl">›</span>
                  </div>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-[90%] max-h-[80vh] overflow-auto bg-[#FEFDF9] rounded-3xl border-[#6BBDE2]/20">
                <DialogHeader>
                  <DialogTitle className="text-[#2c3e50]">{tool.title}</DialogTitle>
                  <DialogDescription className="text-gray-600">{tool.description}</DialogDescription>
                </DialogHeader>
                {tool.id === 'pomodoro' && <PomodoroTimer />}
                {tool.id === 'flashcards' && <FlashCards />}
                {tool.id === 'record' && <AIRecord />}
                {tool.id === 'notifications' && <PopNotifications />}
                {tool.id === 'feynman' && <FeynmanTechnique />}
                {(tool.id === 'test' || tool.id === 'final-test') && <TestSystem isFinal={tool.id === 'final-test'} />}
              </DialogContent>
            </Dialog>
          );
        })}
      </div>
    </div>
  );
}