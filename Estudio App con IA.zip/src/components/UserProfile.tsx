import { Settings, Award, TrendingUp, Clock, Sparkles, Globe, Mail, Calendar as CalendarIcon, User as UserIcon, Bell, Shield } from 'lucide-react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';

export default function UserProfile() {
  return (
    <div className="p-6 space-y-6 bg-[#FEFDFB] min-h-full pb-20">
      {/* Profile Header */}
      <div className="text-center pt-4">
        <div className="relative w-28 h-28 mx-auto mb-4">
          <div className="absolute inset-0 bg-gradient-to-br from-[#6BBDE2] to-[#4db6e0] rounded-full"></div>
          <div className="absolute inset-2 bg-[#FEFDF9] rounded-full flex items-center justify-center">
            <span className="text-[#6BBDE2]">SA</span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-9 h-9 bg-[#FFC107] rounded-full border-4 border-[#FEFDFB] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
        </div>
        <h2 className="text-[#2c3e50]">Active Student</h2>
        <p className="text-gray-500 mt-1">student@email.com</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="p-5 bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30 shadow-sm">
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-[#6BBDE2] rounded-2xl flex items-center justify-center mb-3">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <p className="text-xs text-gray-600 mb-1">Study Hours</p>
            <p className="text-[#2c3e50]">24.5h</p>
          </div>
        </Card>

        <Card className="p-5 bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/30 shadow-sm">
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-[#FFC107] rounded-2xl flex items-center justify-center mb-3">
              <Award className="w-6 h-6 text-white" />
            </div>
            <p className="text-xs text-gray-600 mb-1">Streak</p>
            <p className="text-[#2c3e50]">7 days</p>
          </div>
        </Card>
      </div>

      {/* Progress Section */}
      <Card className="p-6 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-[#2c3e50]">Weekly Progress</h3>
          <TrendingUp className="w-5 h-5 text-[#6BBDE2]" />
        </div>
        <div className="space-y-5">
          <div>
            <div className="flex justify-between mb-2 text-sm">
              <span className="text-[#2c3e50]">Mathematics</span>
              <span className="text-[#6BBDE2]">85%</span>
            </div>
            <Progress value={85} className="h-2.5 bg-[#e8f4f8]" />
          </div>
          <div>
            <div className="flex justify-between mb-2 text-sm">
              <span className="text-[#2c3e50]">History</span>
              <span className="text-[#6BBDE2]">72%</span>
            </div>
            <Progress value={72} className="h-2.5 bg-[#e8f4f8]" />
          </div>
          <div>
            <div className="flex justify-between mb-2 text-sm">
              <span className="text-[#2c3e50]">Science</span>
              <span className="text-[#6BBDE2]">90%</span>
            </div>
            <Progress value={90} className="h-2.5 bg-[#e8f4f8]" />
          </div>
        </div>
      </Card>

      {/* Account Information */}
      <Card className="p-6 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
        <h3 className="mb-4 text-[#2c3e50]">Account Information</h3>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
              <UserIcon className="w-5 h-5 text-[#6BBDE2]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500">Full Name</p>
              <p className="text-sm text-[#2c3e50]">Sarah Anderson</p>
            </div>
          </div>
          
          <Separator className="bg-[#6BBDE2]/10" />
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
              <Mail className="w-5 h-5 text-[#6BBDE2]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500">Email</p>
              <p className="text-sm text-[#2c3e50]">student@email.com</p>
            </div>
          </div>
          
          <Separator className="bg-[#6BBDE2]/10" />
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
              <Globe className="w-5 h-5 text-[#6BBDE2]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500">Language</p>
              <p className="text-sm text-[#2c3e50]">English (US)</p>
            </div>
          </div>
          
          <Separator className="bg-[#6BBDE2]/10" />
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
              <CalendarIcon className="w-5 h-5 text-[#6BBDE2]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500">Member Since</p>
              <p className="text-sm text-[#2c3e50]">September 1, 2025</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Settings Options */}
      <div className="space-y-3">
        <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm hover:shadow-md transition-shadow">
          <button className="w-full flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-[#6BBDE2]" />
              </div>
              <span className="text-[#2c3e50]">Notifications</span>
            </div>
            <span className="text-[#6BBDE2]">›</span>
          </button>
        </Card>

        <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm hover:shadow-md transition-shadow">
          <button className="w-full flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#6BBDE2]" />
              </div>
              <span className="text-[#2c3e50]">Privacy & Security</span>
            </div>
            <span className="text-[#6BBDE2]">›</span>
          </button>
        </Card>

        <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm hover:shadow-md transition-shadow">
          <button className="w-full flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
                <Settings className="w-5 h-5 text-[#6BBDE2]" />
              </div>
              <span className="text-[#2c3e50]">Settings</span>
            </div>
            <span className="text-[#6BBDE2]">›</span>
          </button>
        </Card>
      </div>

      {/* Achievement */}
      <Card className="p-6 bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/40 shadow-md">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-[#FFC107] rounded-2xl flex items-center justify-center shadow-lg">
            <Award className="w-7 h-7 text-white" />
          </div>
          <div>
            <h4 className="text-[#2c3e50]">Achievement Unlocked!</h4>
            <p className="text-sm text-gray-600 mt-1">7 days streak completed</p>
          </div>
        </div>
      </Card>
    </div>
  );
}