import { useState } from 'react';
import { BookOpen, Mic2, Plus, Sparkles } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import NotebookViewer from './NotebookViewer';

export default function Wiki() {
  const [notebooks] = useState([
    { id: 1, title: 'Advanced Mathematics', notes: 24, color: 'bg-gradient-to-br from-[#6BBDE2] to-[#4db6e0]' },
    { id: 2, title: 'World History', notes: 18, color: 'bg-gradient-to-br from-[#FFC107] to-[#ffb300]' },
    { id: 3, title: 'Organic Chemistry', notes: 31, color: 'bg-gradient-to-br from-[#8dd4f0] to-[#6BBDE2]' },
    { id: 4, title: 'Modern Literature', notes: 12, color: 'bg-gradient-to-br from-[#ffd54f] to-[#FFC107]' },
  ]);

  const [recordings] = useState([
    { id: 1, title: 'Calculus Class - Sep 28', duration: '45:23', status: 'Processed' },
    { id: 2, title: 'History Lecture', duration: '1:02:15', status: 'Processing' },
    { id: 3, title: 'Chemistry Review', duration: '28:40', status: 'Processed' },
  ]);

  const [selectedNotebook, setSelectedNotebook] = useState<typeof notebooks[0] | null>(null);

  if (selectedNotebook) {
    return <NotebookViewer notebook={selectedNotebook} onBack={() => setSelectedNotebook(null)} />;
  }

  return (
    <div className="h-full flex flex-col bg-[#FEFDFB]">
      <div className="p-6 pb-8 bg-gradient-to-br from-[#6BBDE2] to-[#4db6e0] text-white rounded-b-3xl shadow-lg">
        <h1 className="text-white">My Wiki</h1>
        <p className="text-white/90 mt-1">Your knowledge library</p>
      </div>

      <Tabs defaultValue="notebooks" className="flex-1 flex flex-col">
        <TabsList className="mx-6 mt-[-20px] grid w-auto grid-cols-2 bg-[#FEFDF9] shadow-md border border-[#6BBDE2]/20 rounded-2xl">
          <TabsTrigger value="notebooks" className="rounded-xl data-[state=active]:bg-[#6BBDE2] data-[state=active]:text-white">
            <BookOpen className="w-4 h-4 mr-2" />
            E-Notebooks
          </TabsTrigger>
          <TabsTrigger value="recordings" className="rounded-xl data-[state=active]:bg-[#6BBDE2] data-[state=active]:text-white">
            <Mic2 className="w-4 h-4 mr-2" />
            AI Recordings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notebooks" className="flex-1 p-6 space-y-4 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#2c3e50]">My Notebooks</h3>
            <Button size="sm" className="bg-[#6BBDE2] hover:bg-[#5aaedb] text-white rounded-full shadow-md">
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </div>

          {notebooks.map((notebook) => (
            <Card
              key={notebook.id}
              className="p-5 bg-[#FEFDF9] border-[#6BBDE2]/20 hover:shadow-lg transition-all cursor-pointer shadow-sm"
              onClick={() => setSelectedNotebook(notebook)}
            >
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 ${notebook.color} rounded-2xl flex items-center justify-center shadow-md`}>
                  <BookOpen className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-[#2c3e50]">{notebook.title}</h4>
                  <div className="flex items-center gap-3 mt-2">
                    <Badge variant="secondary" className="text-xs bg-[#e8f4f8] text-[#6BBDE2] border-0">
                      {notebook.notes} notes
                    </Badge>
                    <span className="text-xs text-gray-500">Updated 2 days ago</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}

          <Card className="p-6 bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30 border-dashed border-2 shadow-sm">
            <div className="text-center">
              <div className="w-14 h-14 bg-[#6BBDE2] rounded-full mx-auto mb-3 flex items-center justify-center shadow-lg">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <h4 className="text-[#2c3e50]">Organize your knowledge</h4>
              <p className="text-sm text-gray-600 mt-2">
                Create virtual notebooks for each subject. Add notes, photos, and AI will use them to create personalized questions.
              </p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="recordings" className="flex-1 p-6 space-y-4 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[#2c3e50]">Recordings</h3>
            <Button size="sm" className="bg-[#6BBDE2] hover:bg-[#5aaedb] text-white rounded-full shadow-md">
              <Mic2 className="w-4 h-4 mr-1" />
              Record
            </Button>
          </div>

          {recordings.map((recording) => (
            <Card key={recording.id} className="p-5 bg-[#FEFDF9] border-[#6BBDE2]/20 hover:shadow-lg transition-all cursor-pointer shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-[#e8f4f8] rounded-2xl flex items-center justify-center shadow-md">
                  <Mic2 className="w-7 h-7 text-[#6BBDE2]" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm text-[#2c3e50]">{recording.title}</h4>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-gray-500">{recording.duration}</span>
                    <Badge 
                      className={`text-xs border-0 ${
                        recording.status === 'Processed' 
                          ? 'bg-[#e8f4f8] text-[#6BBDE2]' 
                          : 'bg-[#fff9e6] text-[#FFC107]'
                      }`}
                    >
                      {recording.status}
                    </Badge>
                  </div>
                </div>
              </div>
              
              {recording.status === 'Processed' && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1 text-xs border-[#6BBDE2] text-[#6BBDE2] rounded-xl hover:bg-[#e8f4f8]">
                      Summary
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 text-xs border-[#6BBDE2] text-[#6BBDE2] rounded-xl hover:bg-[#e8f4f8]">
                      Mind Map
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 text-xs border-[#6BBDE2] text-[#6BBDE2] rounded-xl hover:bg-[#e8f4f8]">
                      Save
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          ))}

          <Card className="p-6 bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/40 border-dashed border-2 shadow-sm">
            <div className="text-center">
              <div className="w-14 h-14 bg-[#FFC107] rounded-full mx-auto mb-3 flex items-center justify-center shadow-lg">
                <Mic2 className="w-7 h-7 text-white" />
              </div>
              <h4 className="text-[#2c3e50]">Turn audio into knowledge</h4>
              <p className="text-sm text-gray-600 mt-2">
                Record classes or import audio. AI will transcribe, create summaries and mind maps automatically.
              </p>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}