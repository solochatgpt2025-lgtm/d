import { useState } from 'react';
import { Mic, Square, Upload, FileAudio } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Progress } from '../ui/progress';

export default function AIRecord() {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  return (
    <div className="space-y-6">
      <Card className="p-8 bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30 shadow-lg">
        <div className="text-center">
          <div className={`w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center shadow-xl ${
            isRecording ? 'bg-[#FFC107] animate-pulse' : 'bg-[#6BBDE2]'
          }`}>
            {isRecording ? (
              <Square className="w-10 h-10 text-white" />
            ) : (
              <Mic className="w-10 h-10 text-white" />
            )}
          </div>
          
          {isRecording && (
            <div className="mb-6">
              <p className="text-2xl tabular-nums mb-2 text-[#2c3e50]">
                {Math.floor(recordingTime / 60)}:{String(recordingTime % 60).padStart(2, '0')}
              </p>
              <p className="text-sm text-gray-600">Recording...</p>
            </div>
          )}

          <Button
            onClick={() => setIsRecording(!isRecording)}
            size="lg"
            className={`rounded-2xl shadow-lg ${
              isRecording 
                ? 'bg-[#FFC107] hover:bg-[#ffb300]' 
                : 'bg-[#6BBDE2] hover:bg-[#5aaedb]'
            } text-white`}
          >
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </Button>
        </div>
      </Card>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300" />
        </div>
        <div className="relative flex justify-center">
          <span className="bg-[#FEFDF9] px-3 text-sm text-gray-500">or</span>
        </div>
      </div>

      <Button variant="outline" className="w-full rounded-2xl border-[#6BBDE2]/30 text-[#6BBDE2] hover:bg-[#e8f4f8]" size="lg">
        <Upload className="w-5 h-5 mr-2" />
        Import Audio
      </Button>

      <div className="space-y-3">
        <h4 className="text-[#2c3e50]">Recent Recordings</h4>
        
        <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-[#fff9e6] rounded-xl flex items-center justify-center">
              <FileAudio className="w-5 h-5 text-[#FFC107]" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#2c3e50]">Physics Class - Thermodynamics</p>
              <p className="text-xs text-gray-500">42:18 • Processing</p>
            </div>
          </div>
          <Progress value={65} className="h-2 bg-[#e8f4f8]" />
          <p className="text-xs text-gray-500 mt-2">Transcribing and generating summary...</p>
        </Card>

        <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e8f4f8] rounded-xl flex items-center justify-center">
              <FileAudio className="w-5 h-5 text-[#6BBDE2]" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#2c3e50]">Organic Chemistry Review</p>
              <p className="text-xs text-gray-500">28:45 • Completed</p>
            </div>
            <Button size="sm" variant="outline" className="rounded-xl border-[#6BBDE2] text-[#6BBDE2] hover:bg-[#e8f4f8]">
              View
            </Button>
          </div>
        </Card>
      </div>

      <div className="p-4 bg-[#e8f4f8] rounded-2xl border border-[#6BBDE2]/30">
        <p className="text-sm text-gray-700">
          <strong className="text-[#2c3e50]">AI Record:</strong> AI transcribes your audio, identifies key concepts and generates automatic summaries you can save to your e-notebooks.
        </p>
      </div>
    </div>
  );
}