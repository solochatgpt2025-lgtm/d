import { useState } from 'react';
import { Lightbulb, ArrowRight } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

export default function FeynmanTechnique() {
  const [step, setStep] = useState(0);

  const concepts = [
    {
      term: 'Photosynthesis',
      question: 'How would you explain photosynthesis to an 8-year-old?',
      synonyms: [
        { word: 'process', options: ['mechanism', 'method', 'way of doing something', 'activity'], correct: 2 },
        { word: 'energy', options: ['power', 'vital force', 'fuel', 'ability to work'], correct: 3 },
        { word: 'conversion', options: ['transformation', 'change', 'turning one thing into another', 'modification'], correct: 2 },
      ],
      selected: [null, null, null],
    },
  ];

  const currentConcept = concepts[0];
  const currentSynonym = currentConcept.synonyms[step];

  const handleSelect = (index: number) => {
    if (step < currentConcept.synonyms.length - 1) {
      setStep(step + 1);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/40 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-[#FFC107] rounded-2xl flex items-center justify-center shadow-md">
            <Lightbulb className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-[#2c3e50]">Feynman Technique</h4>
            <p className="text-sm text-gray-600 mt-1">
              Simplify complex concepts to understand them better
            </p>
          </div>
        </div>
      </Card>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-[#2c3e50]">Concept: {currentConcept.term}</h4>
          <Badge className="bg-[#6BBDE2] text-white">{step + 1} of {currentConcept.synonyms.length}</Badge>
        </div>
        
        <Card className="p-6 bg-[#FEFDF9] mb-6 border-[#6BBDE2]/20 shadow-sm">
          <p className="text-gray-600 mb-4">{currentConcept.question}</p>
          
          <div className="p-4 bg-[#e8f4f8] rounded-2xl">
            <p className="text-sm text-gray-700">
              To explain it simply, try replacing the word{' '}
              <strong className="text-[#6BBDE2]">"{currentSynonym.word}"</strong> with an easier expression:
            </p>
          </div>
        </Card>

        <div className="space-y-3">
          {currentSynonym.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleSelect(index)}
              className="w-full p-4 text-left bg-[#FEFDF9] border-2 border-[#6BBDE2]/20 rounded-2xl hover:border-[#6BBDE2] hover:bg-[#e8f4f8] transition-all shadow-sm hover:shadow-md"
            >
              <div className="flex items-center justify-between">
                <span className="text-[#2c3e50]">{option}</span>
                {index === currentSynonym.correct && (
                  <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                    Simpler
                  </Badge>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {step === currentConcept.synonyms.length - 1 && (
        <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-md">
          <div className="text-center">
            <div className="w-14 h-14 bg-green-500 rounded-full mx-auto mb-3 flex items-center justify-center shadow-lg">
              <ArrowRight className="w-7 h-7 text-white" />
            </div>
            <h4 className="text-[#2c3e50]">Excellent!</h4>
            <p className="text-sm text-gray-600 mt-2">
              You've simplified the concept. Now try to explain it in your own words.
            </p>
            <Button className="mt-4 bg-green-500 hover:bg-green-600 text-white shadow-md rounded-2xl">
              Next Concept
            </Button>
          </div>
        </Card>
      )}

      <div className="p-4 bg-[#fff9e6] rounded-2xl border border-[#FFC107]/40">
        <p className="text-sm text-gray-700">
          <strong className="text-[#2c3e50]">Feynman Technique:</strong> If you can explain a concept simply, it means you truly understand it.
        </p>
      </div>
    </div>
  );
}