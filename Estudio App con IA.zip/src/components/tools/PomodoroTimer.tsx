import { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';

export default function PomodoroTimer() {
  const [selectedTime, setSelectedTime] = useState<{ work: number; break: number }>({ work: 25, break: 5 });
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);

  const presets = [
    { work: 10, break: 5, label: '10/5' },
    { work: 25, break: 5, label: '25/5' },
    { work: 60, break: 10, label: '60/10' },
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      if (!isBreak) {
        setIsBreak(true);
        setTimeLeft(selectedTime.break * 60);
      } else {
        setIsBreak(false);
        setTimeLeft(selectedTime.work * 60);
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, isBreak, selectedTime]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  const handleReset = () => {
    setIsRunning(false);
    setIsBreak(false);
    setTimeLeft(selectedTime.work * 60);
  };

  const handlePresetChange = (work: number, breakTime: number) => {
    setSelectedTime({ work, break: breakTime });
    setTimeLeft(work * 60);
    setIsRunning(false);
    setIsBreak(false);
  };

  return (
    <div className="space-y-6">
      <Card className="p-8 bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/30">
        <div className="text-center">
          <p className="text-sm text-gray-600 mb-3">
            {isBreak ? 'Break time' : 'Study time'}
          </p>
          <div className="relative w-48 h-48 mx-auto mb-6">
            <div className="absolute inset-0 bg-gradient-to-br from-[#FFC107] to-[#ffb300] rounded-full opacity-20"></div>
            <div className="absolute inset-4 bg-[#FEFDF9] rounded-full shadow-xl flex items-center justify-center border-4 border-white">
              <span className="text-5xl tabular-nums text-[#2c3e50]">
                {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
              </span>
            </div>
          </div>
          
          <div className="flex justify-center gap-3">
            <Button
              onClick={() => setIsRunning(!isRunning)}
              size="lg"
              className="bg-gradient-to-r from-[#FFC107] to-[#ffb300] hover:from-[#ffb300] hover:to-[#FFC107] text-white shadow-lg rounded-2xl"
            >
              {isRunning ? <Pause className="w-5 h-5 mr-2" /> : <Play className="w-5 h-5 mr-2" />}
              {isRunning ? 'Pause' : 'Start'}
            </Button>
            <Button onClick={handleReset} size="lg" variant="outline" className="rounded-2xl border-[#FFC107]/30 text-[#FFC107] hover:bg-[#fff9e6]">
              <RotateCcw className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </Card>

      <div>
        <p className="mb-3 text-[#2c3e50]">Select a preset:</p>
        <div className="grid grid-cols-3 gap-3">
          {presets.map((preset) => (
            <Button
              key={preset.label}
              onClick={() => handlePresetChange(preset.work, preset.break)}
              variant={selectedTime.work === preset.work ? 'default' : 'outline'}
              className={`rounded-2xl ${
                selectedTime.work === preset.work 
                  ? 'bg-[#FFC107] hover:bg-[#ffb300] text-white shadow-md' 
                  : 'border-[#FFC107]/30 text-[#FFC107] hover:bg-[#fff9e6]'
              }`}
            >
              {preset.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="p-4 bg-[#fff9e6] rounded-2xl border border-[#FFC107]/30">
        <p className="text-sm text-gray-700">
          <strong className="text-[#2c3e50]">Pomodoro Technique:</strong> Work in focused intervals followed by short breaks to maximize your productivity.
        </p>
      </div>
    </div>
  );
}