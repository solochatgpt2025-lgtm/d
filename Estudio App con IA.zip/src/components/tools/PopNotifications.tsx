import { useState } from 'react';
import { Bell, Clock, Zap } from 'lucide-react';
import { Card } from '../ui/card';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';

export default function PopNotifications() {
  const [isEnabled, setIsEnabled] = useState(true);

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-[#6BBDE2] rounded-2xl flex items-center justify-center shadow-md">
            <Bell className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-[#2c3e50]">Pop Notifications</h4>
              <Switch checked={isEnabled} onCheckedChange={setIsEnabled} />
            </div>
            <p className="text-sm text-gray-600">
              Get surprise questions to reinforce your learning in real-time
            </p>
          </div>
        </div>
      </Card>

      <div className="space-y-4">
        <div>
          <label className="block mb-3 text-[#2c3e50]">Notification frequency</label>
          <Select defaultValue="30">
            <SelectTrigger className="rounded-2xl border-[#6BBDE2]/30">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-2xl">
              <SelectItem value="15">Every 15 minutes</SelectItem>
              <SelectItem value="30">Every 30 minutes</SelectItem>
              <SelectItem value="60">Every hour</SelectItem>
              <SelectItem value="random">Random</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block mb-3 text-[#2c3e50]">Current study topic</label>
          <Select defaultValue="math">
            <SelectTrigger className="rounded-2xl border-[#6BBDE2]/30">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-2xl">
              <SelectItem value="math">Mathematics</SelectItem>
              <SelectItem value="history">History</SelectItem>
              <SelectItem value="science">Science</SelectItem>
              <SelectItem value="literature">Literature</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block mb-3 text-[#2c3e50]">Question types</label>
          <div className="space-y-2">
            <Card className="p-3 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="border-[#6BBDE2] text-[#6BBDE2]">ABC</Badge>
                  <span className="text-sm text-[#2c3e50]">Multiple choice</span>
                </div>
                <Switch defaultChecked />
              </div>
            </Card>
            <Card className="p-3 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="border-[#6BBDE2] text-[#6BBDE2]">Text</Badge>
                  <span className="text-sm text-[#2c3e50]">Open answer</span>
                </div>
                <Switch defaultChecked />
              </div>
            </Card>
            <Card className="p-3 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="border-[#6BBDE2] text-[#6BBDE2]">Timeline</Badge>
                  <span className="text-sm text-[#2c3e50]">Timeline order</span>
                </div>
                <Switch />
              </div>
            </Card>
            <Card className="p-3 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="border-[#6BBDE2] text-[#6BBDE2]">Match</Badge>
                  <span className="text-sm text-[#2c3e50]">Match concepts</span>
                </div>
                <Switch defaultChecked />
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Card className="p-4 bg-[#fff9e6] border-[#FFC107]/40 shadow-md rounded-2xl">
        <div className="flex gap-3">
          <Zap className="w-5 h-5 text-[#FFC107] flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm text-[#2c3e50] mb-1">Adaptive AI</h4>
            <p className="text-sm text-gray-600">
              The system learns from your answers and focuses on topics that challenge you most, optimizing your learning.
            </p>
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#6BBDE2]" />
            <span className="text-sm text-[#2c3e50]">Today's stats</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl text-[#2c3e50]">12</p>
            <p className="text-xs text-gray-500">Questions</p>
          </div>
          <div>
            <p className="text-2xl text-[#6BBDE2]">83%</p>
            <p className="text-xs text-gray-500">Correct</p>
          </div>
          <div>
            <p className="text-2xl text-[#FFC107]">8</p>
            <p className="text-xs text-gray-500">Streak</p>
          </div>
        </div>
      </Card>
    </div>
  );
}