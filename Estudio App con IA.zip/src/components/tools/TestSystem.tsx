import { useState } from 'react';
import { FileCheck, Trophy, Star } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Label } from '../ui/label';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';

interface TestSystemProps {
  isFinal?: boolean;
}

export default function TestSystem({ isFinal = false }: TestSystemProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      question: 'What is the derivative of x²?',
      options: ['2x', 'x', '2', 'x²'],
      correct: '2x',
    },
    {
      question: 'When did the Berlin Wall fall?',
      options: ['1987', '1989', '1990', '1991'],
      correct: '1989',
    },
    {
      question: 'What is the chemical symbol for gold?',
      options: ['Go', 'Au', 'Or', 'Ag'],
      correct: 'Au',
    },
  ];

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      setShowResults(true);
    }
  };

  if (showResults) {
    return (
      <div className="space-y-6">
        <Card className={`p-8 text-center shadow-lg ${
          isFinal 
            ? 'bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/40' 
            : 'bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30'
        }`}>
          <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center shadow-xl ${
            isFinal ? 'bg-[#FFC107]' : 'bg-[#6BBDE2]'
          }`}>
            {isFinal ? (
              <Trophy className="w-10 h-10 text-white" />
            ) : (
              <Star className="w-10 h-10 text-white" />
            )}
          </div>
          <h3 className="text-[#2c3e50]">Test Completed!</h3>
          <p className="text-4xl my-4 text-[#2c3e50]">87%</p>
          <p className="text-gray-600">
            {isFinal 
              ? 'Almost! You need 95% to get the discount. Try again in 3 hours.'
              : 'Good work. Keep practicing to improve.'}
          </p>
          
          {isFinal && (
            <div className="mt-6 p-4 bg-[#fff9e6] rounded-2xl border border-[#FFC107]/30">
              <p className="text-sm text-gray-700">
                <strong className="text-[#2c3e50]">Next attempt:</strong> 2 hours 45 minutes
              </p>
            </div>
          )}
        </Card>

        <Card className="p-6 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
          <h4 className="mb-4 text-[#2c3e50]">Answer breakdown</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2c3e50]">Correct</span>
              <Badge className="bg-[#6BBDE2] text-white">2 / 3</Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2c3e50]">Incorrect</span>
              <Badge className="bg-[#FFC107] text-white">1 / 3</Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2c3e50]">Total time</span>
              <span className="text-gray-600">4m 32s</span>
            </div>
          </div>
        </Card>

        <Button className="w-full bg-[#6BBDE2] hover:bg-[#5aaedb] text-white shadow-md rounded-2xl" onClick={() => window.location.reload()}>
          New Test
        </Button>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="space-y-6">
      <Card className={`p-6 shadow-lg ${
        isFinal 
          ? 'bg-gradient-to-br from-[#fff9e6] to-[#ffecb3] border-[#FFC107]/40' 
          : 'bg-gradient-to-br from-[#e8f4f8] to-[#d0ebf5] border-[#6BBDE2]/30'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {isFinal ? (
              <Trophy className="w-6 h-6 text-[#FFC107]" />
            ) : (
              <FileCheck className="w-6 h-6 text-[#6BBDE2]" />
            )}
            <h4 className="text-[#2c3e50]">{isFinal ? 'Final Test' : 'Practice Test'}</h4>
          </div>
          <span className="text-sm text-gray-600">
            {currentQuestion + 1} / {questions.length}
          </span>
        </div>
        <Progress value={((currentQuestion + 1) / questions.length) * 100} className={`h-2 ${isFinal ? 'bg-[#fff9e6]' : 'bg-[#e8f4f8]'}`} />
      </Card>

      <Card className="p-6 bg-[#FEFDF9] border-[#6BBDE2]/20 shadow-sm">
        <p className="mb-6 text-[#2c3e50]">{question.question}</p>
        
        <RadioGroup value={selectedAnswer || ''} onValueChange={setSelectedAnswer}>
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-3 p-4 border-2 border-[#6BBDE2]/20 rounded-2xl hover:border-[#6BBDE2] transition-colors bg-[#FEFDF9]">
                <RadioGroupItem value={option} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer text-[#2c3e50]">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>
      </Card>

      <Button 
        className={`w-full shadow-md rounded-2xl text-white ${
          isFinal 
            ? 'bg-[#FFC107] hover:bg-[#ffb300]' 
            : 'bg-[#6BBDE2] hover:bg-[#5aaedb]'
        }`}
        disabled={!selectedAnswer}
        onClick={handleNext}
      >
        {currentQuestion < questions.length - 1 ? 'Next' : 'Finish'}
      </Button>

      {isFinal && (
        <div className="p-4 bg-[#fff9e6] rounded-2xl border border-[#FFC107]/40">
          <p className="text-sm text-gray-700">
            <strong className="text-[#2c3e50]">Final Test:</strong> Complete with +95% accuracy to get a special discount on the app.
          </p>
        </div>
      )}
    </div>
  );
}